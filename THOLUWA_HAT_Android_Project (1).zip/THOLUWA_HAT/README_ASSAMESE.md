# THOLUWA HAT (থলুৱা হাট) — প্ৰথম Android prototype

এই project-ত আছে:
- Assam-inspired colour theme আৰু simple brand mark
- Welcome/splash-like screen
- Login screen (demo only; OTP authentication সংযোগ কৰা হোৱা নাই)
- Home screen with search input, language toggle, sample district selector, categories

গুৰুত্বপূৰ্ণ সীমাবদ্ধতা:
- এইটো প্ৰথম UI prototype, production marketplace নহয়।
- Login-এ প্ৰকৃত user authenticate নকৰে।
- Search-এ এতিয়াও backend-ৰ product search নকৰে।
- District list-ত এতিয়া sample districts আছে; সম্পূৰ্ণ 35 district পিছৰ ধাপত যোগ কৰিব লাগিব।
- Live products, seller shops, image uploads, orders, Firebase, subscription আৰু payments এতিয়াও সংযোগ কৰা হোৱা নাই।
- APK এই archive-ত prebuilt ৰূপত নাই। GitHub Actions workflow-এ project GitHub-ত upload কৰি workflow চলালে debug APK build কৰাৰ চেষ্টা কৰিব।

Build workflow: `.github/workflows/build-apk.yml`
