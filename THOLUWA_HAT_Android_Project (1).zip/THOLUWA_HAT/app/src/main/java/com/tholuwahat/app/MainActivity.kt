package com.tholuwahat.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val GamusaRed = Color(0xFFB71C32)
private val MugaGold = Color(0xFFD5A33B)
private val Ivory = Color(0xFFFFFBF1)
private val DeepGreen = Color(0xFF185B43)
private val Ink = Color(0xFF172B25)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TholuwaHatApp() }
    }
}

@Composable
fun TholuwaHatApp() {
    var page by remember { mutableStateOf("welcome") }
    var language by remember { mutableStateOf("অসমীয়া") }
    MaterialTheme(colorScheme = lightColorScheme(primary = GamusaRed, secondary = MugaGold, background = Ivory)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Ivory) {
            when (page) {
                "welcome" -> WelcomeScreen(onContinue = { page = "login" })
                "login" -> LoginScreen(onContinue = { page = "home" }, onBack = { page = "welcome" })
                else -> HomeScreen(language = language, onLanguage = { language = it }, onLogout = { page = "login" })
            }
        }
    }
}

@Composable
private fun BrandMark(size: Int = 88) {
    Box(
        modifier = Modifier.size(size.dp).background(GamusaRed, RoundedCornerShape((size / 4).dp)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text("⌂", fontSize = (size / 2.3).sp, color = Ivory, fontWeight = FontWeight.Bold, lineHeight = (size / 2.4).sp)
            Box(Modifier.width((size * .56).dp).height(3.dp).background(MugaGold))
        }
    }
}

@Composable
private fun WelcomeScreen(onContinue: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        BrandMark(112)
        Spacer(Modifier.height(24.dp))
        Text("THOLUWA HAT", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = DeepGreen, letterSpacing = 1.5.sp)
        Text("থলুৱা হাট", fontSize = 29.sp, fontWeight = FontWeight.Bold, color = GamusaRed)
        Spacer(Modifier.height(12.dp))
        Text("আপোনাৰ ওচৰৰ বজাৰ,\nআপোনাৰ নিজৰ দোকান।", fontSize = 17.sp, color = Ink, textAlign = TextAlign.Center, lineHeight = 27.sp)
        Spacer(Modifier.height(42.dp))
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = GamusaRed), shape = RoundedCornerShape(16.dp)) {
            Text("আৰম্ভ কৰক  /  Get Started", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(20.dp))
        Text("অসমৰ নিজৰ স্থানীয় বজাৰ", color = DeepGreen, fontSize = 14.sp)
    }
}

@Composable
private fun LoginScreen(onContinue: () -> Unit, onBack: () -> Unit) {
    var phone by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("←", fontSize = 28.sp, color = GamusaRed, modifier = Modifier.clickable { onBack() }.padding(8.dp))
            Spacer(Modifier.width(8.dp))
            Text("Login / লগ-ইন", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = DeepGreen)
        }
        Spacer(Modifier.height(36.dp))
        BrandMark(76)
        Spacer(Modifier.height(18.dp))
        Text("আপোনাক স্বাগতম", fontSize = 24.sp, color = Ink, fontWeight = FontWeight.Bold)
        Text("Welcome to your local market", color = Color.Gray)
        Spacer(Modifier.height(30.dp))
        OutlinedTextField(
            value = phone, onValueChange = { phone = it.filter(Char::isDigit).take(10); message = "" },
            modifier = Modifier.fillMaxWidth(), label = { Text("Mobile number / ম'বাইল নম্বৰ") },
            placeholder = { Text("10-digit mobile number") }, singleLine = true,
            shape = RoundedCornerShape(14.dp)
        )
        Spacer(Modifier.height(16.dp))
        Button(onClick = { message = if (phone.length == 10) "এইটো demo screen। OTP login এতিয়াও সংযোগ কৰা হোৱা নাই।" else "অনুগ্ৰহ কৰি ১০টা digit লিখক।" }, modifier = Modifier.fillMaxWidth().height(52.dp), colors = ButtonDefaults.buttonColors(containerColor = GamusaRed), shape = RoundedCornerShape(14.dp)) {
            Text("Continue / আগবাঢ়ক", fontWeight = FontWeight.Bold)
        }
        if (message.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            Text(message, color = DeepGreen, textAlign = TextAlign.Center, fontSize = 13.sp)
        }
        Spacer(Modifier.height(22.dp))
        Text("Prototype preview: OTP authentication is not connected yet.", color = Color.Gray, fontSize = 12.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.weight(1f))
        Text("আপোনাৰ ওচৰৰ বজাৰ, আপোনাৰ নিজৰ দোকান।", color = DeepGreen, textAlign = TextAlign.Center, fontSize = 13.sp)
    }
}

private data class MarketCategory(val assamese: String, val english: String, val symbol: String)
private val categories = listOf(
    MarketCategory("গামোচা", "Gamusa", "▧"),
    MarketCategory("হস্ততাঁত", "Handloom", "✦"),
    MarketCategory("শাক-পাচলি", "Vegetables", "❋"),
    MarketCategory("চাউল", "Rice", "◉"),
    MarketCategory("পিঠা", "Pitha", "◌"),
    MarketCategory("হস্তশিল্প", "Handicrafts", "✿")
)

@Composable
private fun HomeScreen(language: String, onLanguage: (String) -> Unit, onLogout: () -> Unit) {
    var query by remember { mutableStateOf("") }
    var district by remember { mutableStateOf("যোৰহাট / Jorhat") }
    var districtMenu by remember { mutableStateOf(false) }
    val districts = listOf("বাক্সা / Baksa", "বৰপেটা / Barpeta", "কাছাৰ / Cachar", "দৰং / Darrang", "ডিব্ৰুগড় / Dibrugarh", "গুৱাহাটী / Kamrup Metro", "যোৰহাট / Jorhat", "কামৰূপ / Kamrup", "লখিমপুৰ / Lakhimpur", "শিৱসাগৰ / Sivasagar", "তিনিচুকীয়া / Tinsukia")
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Column(Modifier.fillMaxWidth().background(DeepGreen).padding(horizontal = 20.dp, vertical = 20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BrandMark(48)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("THOLUWA HAT", color = Ivory, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold)
                        Text("থলুৱা হাট", color = MugaGold, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(if (language == "অসমীয়া") "অসমীয়া" else "English", color = Ivory, modifier = Modifier.clickable { onLanguage(if (language == "অসমীয়া") "English" else "অসমীয়া") }.padding(6.dp), fontSize = 12.sp)
                }
                Spacer(Modifier.height(20.dp))
                Text("আপোনাৰ ওচৰৰ বজাৰ", color = Ivory, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                Text("Discover products from local Assam sellers", color = Color(0xFFDDE9D9), fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search products / বস্তু বিচাৰক") }, singleLine = true, shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(focusedContainerColor = Ivory, unfocusedContainerColor = Ivory, focusedBorderColor = MugaGold, unfocusedBorderColor = Ivory))
                Spacer(Modifier.height(12.dp))
                Box {
                    Surface(color = Color(0xFF286B50), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().clickable { districtMenu = true }) {
                        Text("⌖  জিলাখন বাছনি কৰক:  $district   ▾", color = Ivory, modifier = Modifier.padding(14.dp), fontSize = 14.sp)
                    }
                    DropdownMenu(expanded = districtMenu, onDismissRequest = { districtMenu = false }) {
                        districts.forEach { d -> DropdownMenuItem(text = { Text(d) }, onClick = { district = d; districtMenu = false }) }
                    }
                }
            }
        }
        item {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 20.dp)) {
                Text("বিভাগসমূহ / Categories", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                categories.chunked(3).forEach { rowItems ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        rowItems.forEach { category ->
                            Column(Modifier.weight(1f).padding(bottom = 10.dp).background(Color.White, RoundedCornerShape(16.dp)).padding(vertical = 16.dp, horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Box(Modifier.size(42.dp).background(Color(0xFFFFF0E9), CircleShape), contentAlignment = Alignment.Center) { Text(category.symbol, color = GamusaRed, fontSize = 24.sp) }
                                Spacer(Modifier.height(8.dp))
                                Text(category.assamese, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                Text(category.english, color = Color.Gray, fontSize = 10.sp, textAlign = TextAlign.Center)
                            }
                        }
                        repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Spacer(Modifier.height(8.dp))
                Text("স্থানীয় বজাৰ / Local Market", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(10.dp))
                Surface(color = Color.White, shape = RoundedCornerShape(16.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Text("আপোনাৰ বজাৰ সাজু কৰি থকা হৈছে", fontSize = 16.sp, color = DeepGreen, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("এই প্ৰথম prototype-ত এতিয়াও live product বা seller data সংযোগ কৰা হোৱা নাই। পিছৰ ধাপত প্ৰকৃত product listing আৰু shop features যোগ কৰিব পাৰি।", fontSize = 13.sp, color = Color.DarkGray, lineHeight = 20.sp)
                    }
                }
                Spacer(Modifier.height(20.dp))
                OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) { Text("Login screen-লৈ উভতি যাওক / Back to Login") }
            }
        }
    }
}
